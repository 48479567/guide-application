<footer><a href="http://www.hostdime.com.co/blog/">Blog HostDime Colombia</a></footer>	
</body>
</html>
